function [coordinate, radius] = gen_patch(max_num, min_num)

% define cell radius
ratio = 0.2;
base_radius = 6;
max_radius = base_radius * (1 + ratio);
min_radius = base_radius * (1 - ratio);

% generate cell num
%max_num = 100;
%min_num = 20;
cur_num = randi([min_num, max_num], 1);
%cur_num = 0;

% initialize mask
mask = zeros(64, 64);
coordinate = zeros(cur_num, 2);
radius = zeros(cur_num, 2);
index = 1;

%fprintf('--- cur_num: %d ---', cur_num);
if cur_num > 0
    for i = 1:10000

        x = randi(64);
        y = randi(64);

        % crop patch to judge wether (x, y) is suitable
        scale = 2;
        left  = uint8(max(1,  x - base_radius/scale));
        right = uint8(min(64, x + base_radius/scale));    
        top   = uint8(max(1,  y - base_radius/scale));
        down  = uint8(min(64, y + base_radius/scale));        
        %crop = mask(left:right, top:down);
        crop = mask(top:down, left:right);

        % if (x, y) is qualified, record (x, y ,radius)
        if sum(crop(:)) == 0        
            coordinate(index, 1) = x;
            coordinate(index, 2) = y;

            rand_x = rand();
            rand_y = rand();        
            radius_x = rand_x * (max_radius - min_radius) + min_radius;
            radius_y = rand_y * (max_radius - min_radius) + min_radius;
            radius(index, 1) = radius_x;
            radius(index, 2) = radius_y;

            mask(y, x) = 1;
            index = index + 1;
        end

        if index > cur_num
            break
        end

    end    
end    
