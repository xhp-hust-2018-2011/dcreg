close all
clear
clc

% FORMAT:  (min_cell_num, max_cell_num, x_rate, y_rate, total_image_num, blur_type, opt)
% blur_type: 'none' | 'gaussian' | 'disk' | 'motion'

% Default: 
% save images  to  [opt.save_folder '/image' ]  folder
% save dotmaps to  [opt.save_folder '/dotmap']  folder

opt.save_folder = './dataset';
gen_dataset(1, 5, 3, 5, 3, 'none', opt);
